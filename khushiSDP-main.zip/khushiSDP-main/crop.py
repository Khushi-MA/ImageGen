import os
from moviepy.editor import VideoFileClip

def crop_video(input_path):
    """Crops a video into a square from the top after removing 1/3 from left and right."""
    try:
        # Load the video
        video = VideoFileClip(input_path)

        # Calculate dimensions for cropping
        width, height = video.size
        crop_width = width // 3
        new_width = width - 2 * crop_width
        square_side = new_width

        if height < square_side:
            print(f"Skipping {input_path}: Height less than square side.")
            return

        # Crop the video
        cropped_video = video.crop(
            x1=crop_width,
            x2=width - crop_width,
            y1=0,
            y2=square_side
        )

        # Write the cropped video to a temporary file
        temp_output = input_path + ".temp.mp4"
        cropped_video.write_videofile(
            temp_output, codec="libx264", audio_codec="aac", fps=video.fps, verbose=False, logger=None
        )

        # Replace the original video with the cropped one
        os.replace(temp_output, input_path)
        print(f"Processed and replaced: {input_path}")
    
    except Exception as e:
        print(f"Error processing {input_path}: {e}")

def process_directory(directory):
    """Recursively processes all video files in a directory and its subfolders."""
    for root, _, files in os.walk(directory):
        for file in files:
            # Check for video file extensions (add more if needed)
            if file.lower().endswith(('.mp4', '.mov', '.avi', '.mkv')):
                file_path = os.path.join(root, file)
                crop_video(file_path)

if __name__ == "__main__":
    # Directory containing the videos
    directory_path = r"data"  # Replace with your directory path

    # Process all videos in the directory and subdirectories
    process_directory(directory_path)
