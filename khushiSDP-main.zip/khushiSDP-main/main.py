import torch
from code.train import train, generate_sequence, tensor_to_video
# from code.test import generate_hand_sequence
# from code.modelmoco import Generator
from code.dataloader import load_data
# main.py
import torch
import os

# Define paths
MODEL_DIR = 'saved_models'
SEQUENCE_DIR = 'generated_sequences'
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(SEQUENCE_DIR, exist_ok=True)

def save_model(model, model_name):
    path = os.path.join(MODEL_DIR, f'{model_name}.pth')
    torch.save(model.state_dict(), path)
    print(f"Model saved to {path}")

def load_model(model, model_name):
    path = os.path.join(MODEL_DIR, f'{model_name}.pth')
    model.load_state_dict(torch.load(path))
    model.eval()
    return model

def main():
    # Load and preprocess data
    word_data = load_data()
    
    # Create word to index mapping
    words = list(word_data.keys())
    word_to_index = {word: idx for idx, word in enumerate(words)}
    print(f"Words Loaded: {words}")
    print(f"Generated word_to_index mapping: {word_to_index}")

    # Training phase
    print("Initializing and training the model...")
    model_params = train(word_data)
    
    # Save trained model
    save_model(model_params['generator'], 'model1')

    # Generation phase
    print("Model training complete. Generating hand sequence for the word 'beautiful'...")
    word = "beautiful"
    
    if word not in word_to_index:
        print(f"Word '{word}' not found in the dataset. Exiting.")
        exit(1)
    
    # Load saved model
    generator = model_params['generator'].__class__(
        model_params['z_dim'], 
        50,  # word_embedding_dim 
        model_params['input_size']
    ).cuda()
    generator = load_model(generator, 'model1')
    
    # Generate sequence
    word_idx = word_to_index[word]
    model_params['generator'] = generator
    generated_sequence = generate_sequence(word_idx, model_params)
    
    # Save generated sequence
    sequence_path = os.path.join(SEQUENCE_DIR, f'{word}_sequence.pt')
    torch.save(generated_sequence, sequence_path)
    print(f"Generated sequence saved to {sequence_path}")
    
    # Convert to video
    tensor_to_video(generated_sequence)

if __name__ == "__main__":
    main()