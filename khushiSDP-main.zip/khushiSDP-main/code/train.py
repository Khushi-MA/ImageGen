import torch
import torch.optim as optim
import torch.nn as nn
import cv2
import numpy as np
import mediapipe as mp
from code.modelmoco import Generator, Discriminator
from code.dataloader import create_dataloader




def train(word_data):
    # Hyperparameters
    z_dim = 100
    word_embedding_dim = 50
    batch_size = 32
    num_epochs = 10
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Validate input
    if not word_data:
        raise ValueError("word_data cannot be empty")

    # Create dataloader
    train_loader = create_dataloader(word_data, batch_size)

    # Get input dimensions
    sample_batch, _ = next(iter(train_loader))
    seq_len, feature_dim = sample_batch.shape[1], sample_batch.shape[2]
    print(f"Input shape: batch_size x {seq_len} x {feature_dim}")

    # Initialize models
    input_size = seq_len * feature_dim
    generator = Generator(z_dim, word_embedding_dim, output_size=input_size).to(device)
    discriminator = Discriminator(input_size=input_size).to(device)

    # Optimizers
    g_optimizer = optim.Adam(generator.parameters(), lr=0.0002, betas=(0.5, 0.999))
    d_optimizer = optim.Adam(discriminator.parameters(), lr=0.0002, betas=(0.5, 0.999))
    criterion = nn.BCELoss()

    try:
        for epoch in range(num_epochs):
            for i, (real_sequences, word_labels) in enumerate(train_loader):
                batch_size = real_sequences.size(0)
                
                # Move to device and reshape
                real_sequences = real_sequences.view(batch_size, -1).to(device)
                word_labels = word_labels.to(device)

                # Train Discriminator
                d_optimizer.zero_grad()
                real_labels = torch.ones(batch_size, 1).to(device)
                real_preds = discriminator(real_sequences)
                d_loss_real = criterion(real_preds, real_labels)
                
                noise = torch.randn(batch_size, z_dim).to(device)
                fake_sequences = generator(noise, word_labels)
                fake_sequences = fake_sequences.view(batch_size, -1)
                fake_labels = torch.zeros(batch_size, 1).to(device)
                fake_preds = discriminator(fake_sequences.detach())
                d_loss_fake = criterion(fake_preds, fake_labels)
                
                d_loss = d_loss_real + d_loss_fake
                d_loss.backward()
                d_optimizer.step()

                # Train Generator
                g_optimizer.zero_grad()
                fake_preds = discriminator(fake_sequences)
                g_loss = criterion(fake_preds, real_labels)
                g_loss.backward()
                g_optimizer.step()

                if i % 10 == 0:
                    print(f"Epoch [{epoch+1}/{num_epochs}] Batch [{i}/{len(train_loader)}] "
                          f"D_loss: {d_loss.item():.4f} G_loss: {g_loss.item():.4f}")

        # Save models
        torch.save(generator.state_dict(), 'generator.pth')
        torch.save(discriminator.state_dict(), 'discriminator.pth')
        
        # Return model parameters for generation
        return {
            'generator': generator,
            'z_dim': z_dim,
            'seq_len': seq_len,
            'feature_dim': feature_dim,
            'input_size': input_size
        }

    except Exception as e:
        print(f"Error during training: {str(e)}")
        raise

def generate_sequence(word_idx, model_params):
    generator = model_params['generator']
    z_dim = model_params['z_dim']
    seq_len = model_params['seq_len']
    feature_dim = model_params['feature_dim']
    
    generator.eval()
    with torch.no_grad():
        noise = torch.randn(1, z_dim).cuda()
        word_label = torch.tensor([word_idx]).cuda()
        fake_sequence = generator(noise, word_label)
        fake_sequence = fake_sequence.view(seq_len, feature_dim)
    
    return fake_sequence.cpu()


def tensor_to_video(sequence, output_path='generated_hand.mp4', fps=30):
    """Convert tensor sequence to video with hand landmarks visualization"""
    
    # Video settings
    frame_size = (640, 480)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, frame_size)
    
    # MediaPipe hands setup
    mp_hands = mp.solutions.hands
    mp_drawing = mp.solutions.drawing_utils
    
    # Create landmark structure
    class HandLandmarkList:
        def __init__(self, x, y):
            self.landmark = [mp.solutions.hands.HandLandmark(i) for i in range(21)]
            self.x = x
            self.y = y
    
    # Convert sequence to landmarks
    for frame_idx in range(sequence.shape[0]):
        # Create blank frame
        frame = np.zeros((frame_size[1], frame_size[0], 3), dtype=np.uint8)
        
        # Scale coordinates to frame size
        x = int(sequence[frame_idx, 0].item() * frame_size[0] + frame_size[0]//2)
        y = int(sequence[frame_idx, 1].item() * frame_size[1] + frame_size[1]//2)
        
        # Draw point
        cv2.circle(frame, (x, y), 5, (0, 255, 0), -1)
        
        # Optional: Draw connection lines
        if frame_idx > 0:
            prev_x = int(sequence[frame_idx-1, 0].item() * frame_size[0] + frame_size[0]//2)
            prev_y = int(sequence[frame_idx-1, 1].item() * frame_size[1] + frame_size[1]//2)
            cv2.line(frame, (prev_x, prev_y), (x, y), (0, 0, 255), 2)
        
        out.write(frame)
    
    out.release()
    print(f"Video saved to {output_path}")
    return output_path
