import torch
from code.modelmoco import Generator

# Assuming the generator is already trained and saved
def generate_hand_sequence(generator, word_to_index, word, noise_dim=100):
    # Check if word exists in word_to_index
    if word not in word_to_index:
        raise ValueError(f"Word '{word}' not found in word_to_index.")

    # Generate random noise as input
    noise = torch.randn(1, noise_dim).cuda()

    # Get the word label by mapping word to index
    word_label = torch.tensor([word_to_index[word]]).cuda()

    # Set the model to evaluation mode
    generator.eval()

    # Generate the sequence using the generator
    with torch.no_grad():  # Disable gradient computation for inference
        generated_sequence = generator(noise, word_label)

    return generated_sequence


# Example: Generate sequence for "beautiful"
# word_to_index should be a dictionary that maps words to indices (you need to create this)
# generated_sequence = generate_hand_sequence(generator, word_to_index, "beautiful")


# # test.py
# import torch
# from model import Generator
# from dataloader import word_data

# # Initialize the generator
# z_dim = 100  # Latent vector size
# word_embedding_dim = 50  # Size of word embedding
# generator = Generator(z_dim, word_embedding_dim).cuda()

# # Load trained weights (make sure to load the trained model before generating)
# # generator.load_state_dict(torch.load('generator.pth'))  # Assuming you saved the trained model

# # Word to index mapping (example)
# word_to_index = {word: idx for idx, word in enumerate(word_data.keys())}

# def generate_hand_sequence(word, noise_dim=100):
#     noise = torch.randn(1, noise_dim).cuda()
#     word_label = torch.tensor([word_to_index[word]]).cuda()  # Map word to an index
#     generated_sequence = generator(noise, word_label)
#     return generated_sequence

# # Example: Generate sequence for "beautiful"
# generated_sequence = generate_hand_sequence("beautiful")
# print(generated_sequence)
