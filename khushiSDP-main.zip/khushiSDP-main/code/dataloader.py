import os
import torch
from torch.utils.data import DataLoader, TensorDataset
from sklearn.preprocessing import LabelEncoder

DATA_pre_DIR = "khushiSDP/processed_data"

import torch
import numpy as np

def load_data():
    word_data = {}
    min_seq_length = 2  # Minimum required sequence length
    
    for filename in os.listdir(DATA_pre_DIR):
        if filename.endswith('.pt'):
            word = filename.split('.')[0]
            file_path = os.path.join(DATA_pre_DIR, filename)
            
            try:
                data = torch.load(file_path)
                print(f"Loading {filename}: {type(data)}")
                
                sequences = []
                
                if isinstance(data, dict):
                    for key, value in data.items():
                        try:
                            # Convert numpy arrays or lists to tensor
                            if not isinstance(value, torch.Tensor):
                                if isinstance(value, (list, np.ndarray)):
                                    value = torch.tensor(value, dtype=torch.float32)
                                else:
                                    print(f"Skipping {key}: invalid data type {type(value)}")
                                    continue

                            # Handle empty or malformed sequences
                            if value.dim() == 2:
                                if value.size(1) == 0:  # Empty sequence
                                    print(f"Fixing empty sequence {key}")
                                    value = torch.zeros((value.size(0), 2), dtype=torch.float32)
                                elif value.size(1) == 1:  # Single dimension
                                    print(f"Padding sequence {key}")
                                    padding = torch.zeros((value.size(0), 1), dtype=torch.float32)
                                    value = torch.cat([value, padding], dim=1)
                                
                                if value.size(1) == 2:
                                    sequences.append(value)
                                else:
                                    print(f"Invalid dimensions for {key}: {value.shape}")
                            else:
                                print(f"Wrong number of dimensions for {key}: {value.dim()}")
                                
                        except Exception as e:
                            print(f"Error processing {key} in {filename}: {str(e)}")
                
                # Only add if we have valid sequences
                if sequences:
                    word_data[word] = sequences
                    print(f"Added {len(sequences)} sequences for {word}")
                else:
                    print(f"No valid sequences found in {filename}")
                    
            except Exception as e:
                print(f"Error loading {filename}: {str(e)}")
                continue
    
    if not word_data:
        raise ValueError("No valid sequences found in any files")
        
    return word_data

def create_dataloader(word_data, batch_size=32):
    sequences = []
    labels = []
    
    # Debug info
    print(f"Creating dataloader with {len(word_data)} categories")
    
    # First pass: validate input and find max length
    max_len = 0
    for word, seqs in word_data.items():
        if not isinstance(seqs, (list, torch.Tensor)):
            print(f"Warning: Skipping invalid data type for {word}: {type(seqs)}")
            continue
            
        if isinstance(seqs, list):
            for seq in seqs:
                if isinstance(seq, torch.Tensor) and seq.dim() == 2:
                    max_len = max(max_len, seq.size(0))
        elif isinstance(seqs, torch.Tensor) and seqs.dim() == 2:
            max_len = max(max_len, seqs.size(0))
            
    print(f"Maximum sequence length: {max_len}")
    
    # Second pass: standardize and pad sequences
    for word, seqs in word_data.items():
        if isinstance(seqs, list):
            for seq in seqs:
                if isinstance(seq, torch.Tensor) and seq.dim() == 2:
                    if seq.size(1) != 2:
                        print(f"Warning: Skipping sequence with invalid features for {word}: {seq.shape}")
                        continue
                        
                    padded_seq = torch.zeros((max_len, 2), dtype=torch.float32)
                    padded_seq[:seq.size(0)] = seq
                    sequences.append(padded_seq)
                    labels.append(word)
        elif isinstance(seqs, torch.Tensor) and seqs.dim() == 2:
            if seqs.size(1) != 2:
                print(f"Warning: Skipping tensor with invalid features for {word}: {seqs.shape}")
                continue
                
            padded_seq = torch.zeros((max_len, 2), dtype=torch.float32)
            padded_seq[:seqs.size(0)] = seqs
            sequences.append(padded_seq)
            labels.append(word)
    
    if not sequences:
        raise ValueError("No valid sequences found after processing")
    
    print(f"Total sequences: {len(sequences)}")
    print(f"Sequence shape: {sequences[0].shape}")
    
    # Convert labels
    label_encoder = LabelEncoder()
    numeric_labels = label_encoder.fit_transform(labels)
    num_classes = len(label_encoder.classes_)
    print(f"Number of classes: {num_classes}")
    
    # Stack and create tensors
    sequences = torch.stack(sequences)
    labels = torch.tensor(numeric_labels, dtype=torch.long)
    
    # Create dataset and loader
    dataset = TensorDataset(sequences, labels)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=0
    )
    
    print(f"Created dataloader with {len(loader)} batches")
    return loader