# modelmoco.py
import torch
import torch.nn as nn

class Generator(nn.Module):
    def __init__(self, z_dim, word_embedding_dim, output_size):
        super(Generator, self).__init__()
        self.z_dim = z_dim
        self.word_embedding_dim = word_embedding_dim
        self.output_size = output_size  # seq_len * feature_dim

        # Embedding layer for word labels
        self.word_embedding = nn.Embedding(num_embeddings=3, embedding_dim=word_embedding_dim)
        
        self.fc = nn.Sequential(
            nn.Linear(z_dim + word_embedding_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 512),
            nn.ReLU(),
            nn.Linear(512, 1024),
            nn.ReLU(),
            nn.Linear(1024, output_size)
        )

    def forward(self, noise, word_label):
        word_embed = self.word_embedding(word_label)
        x = torch.cat([noise, word_embed], dim=1)
        x = self.fc(x)
        return x

class Discriminator(nn.Module):
    def __init__(self, input_size):
        super(Discriminator, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_size, 1024),
            nn.ReLU(),
            nn.Linear(1024, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.fc(x)