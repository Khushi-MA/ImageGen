# Loop through each word and generate 3 sequences
for word in words:
    print(f"\nGenerating sequences for word: {word}")
    word_idx = word_to_index[word]
    model_params['generator'] = generator
    
    for i in range(3):
        # Generate sequence
        generated_sequence = generate_sequence(word_idx, model_params)
        
        # Save sequence with unique name
        sequence_path = os.path.join(SEQUENCE_DIR, f'{word}_sequence_{i+1}.pt')
        torch.save(generated_sequence, sequence_path)
        print(f"Generated sequence {i+1} saved to {sequence_path}")
        
        # Convert to video with unique name
        video_path = f'generated_hand_{word}_{i+1}.mp4'
        tensor_to_video(generated_sequence, output_path=video_path)
        print(f"Video {i+1} saved for word '{word}'")