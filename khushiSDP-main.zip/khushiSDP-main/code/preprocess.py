import os
import torch
import cv2
import mediapipe as mp

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5)
mp_drawing = mp.solutions.drawing_utils

def extract_hand_landmarks(video_path):
    """
    Extract hand landmarks from a video using MediaPipe.
    Returns a list of frame-wise landmark tensors.
    """
    cap = cv2.VideoCapture(video_path)
    landmarks = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        # Convert BGR to RGB for MediaPipe processing
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(frame_rgb)

        frame_landmarks = []
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # Extract landmark coordinates (x, y, z) for each hand
                frame_landmarks.append([[lm.x, lm.y, lm.z] for lm in hand_landmarks.landmark])
        
        # Save landmarks of all detected hands in this frame (or empty list if none found)
        landmarks.append(frame_landmarks)
    
    cap.release()
    return landmarks

def process_category(category_path):
    """
    Process all videos in a category folder and return a dictionary of landmarks.
    """
    video_landmarks = {}
    for video_file in os.listdir(category_path):
        video_path = os.path.join(category_path, video_file)
        if video_file.lower().endswith(('.mp4', '.mov', '.avi')):
            print(f"Processing video: {video_path}")
            video_landmarks[video_file] = extract_hand_landmarks(video_path)
    return video_landmarks

def save_category_to_pt(output_dir, category, data):
    """
    Save the processed landmarks of a category to a .pt file.
    """
    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f"{category}.pt")
    torch.save(data, output_file)
    print(f"Saved {category} landmarks to {output_file}")

def process_and_save_all_categories(input_dir, output_dir):
    """
    Process all categories in the input directory and save the landmarks to .pt files.
    """
    for category in os.listdir(input_dir):
        category_path = os.path.join(input_dir, category)
        if os.path.isdir(category_path):
            print(f"Processing category: {category}")
            category_data = process_category(category_path)
            save_category_to_pt(output_dir, category, category_data)

# Example usage:
# process_and_save_all_categories("path/to/input_dir", "path/to/output_dir")